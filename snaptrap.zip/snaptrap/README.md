# SnapTrap

A Pen created on CodePen.

Original URL: [https://codepen.io/Palakshi-Agrawal/pen/jEWjQME](https://codepen.io/Palakshi-Agrawal/pen/jEWjQME).

